<?php

namespace League\Glide\Filesystem;

use Exception;

class FileNotFoundException extends Exception
{
}
