<?php

namespace League\Glide\Filesystem;

use Exception;

class FilesystemException extends Exception
{
}
