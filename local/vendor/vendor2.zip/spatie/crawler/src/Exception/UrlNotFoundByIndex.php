<?php

namespace Spatie\Crawler\Exception;

use RuntimeException;

class UrlNotFoundByIndex extends RuntimeException
{
}
