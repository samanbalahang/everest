# Changelog

All notable changes to `robots-txt` will be documented in this file


## 1.0.1 - 2018-05-07

- prevent exception if the domain has no robots.txt

## 1.0.0 - 2018-05-07

- initial release
